from django.apps import AppConfig


class SemirestfulAppConfig(AppConfig):
    name = 'semirestful_app'
